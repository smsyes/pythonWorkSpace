#  Copyright Epic Games, Inc. All Rights Reserved.
import logging

# Grab the pose wrangler log
LOG = logging.getLogger("EpicGames.PoseWrangler")
# Set the logging level
LOG.setLevel(logging.DEBUG)
