// --------------------------------------------------------------------------
// multiTrigger.cpp - C++ File
// --------------------------------------------------------------------------
// Copyright �2004 Michael B. Comet  All Rights Reserved
// --------------------------------------------------------------------------
//
// DESCRIPTION:
//	File for multiTrigger node.
//
// AUTHORS:
//		Michael B. Comet - comet@comet-cartoons.com
//
// VERSIONS:
//		1.09 - 11/17/04 - comet - Has multiTrigger support for better usage
//				of multiple nodes at once.  Also has allowRotate option.
//		1.10 - 01/21/05 - mcomet - Now has nodestate HasNoEffect stop.
//
// --------------------------------------------------------------------------
//
//  multiTrigger - Pose Space Value Trigger Maya Plugin by Michael B. Comet
//  Copyright �2004 Michael B. Comet
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//   For information on poseDeformer contact:
//			Michael B. Comet - comet@comet-cartoons.com
//			or visit http://www.comet-cartooons.com/toons/
//
// --------------------------------------------------------------------------

/*
 * Includes
 */
#include <math.h>

#include <maya/MPlug.h>
#include <maya/MDataBlock.h>
#include <maya/MDataHandle.h>
#include <maya/MFnDependencyNode.h>
#include <maya/MFnDagNode.h>

#include <maya/MFnNumericAttribute.h>
#include <maya/MFnCompoundAttribute.h>
#include <maya/MFnEnumAttribute.h>
#include <maya/MFnMatrixAttribute.h>
#include <maya/MFnMessageAttribute.h>

#include <maya/MDoubleArray.h>

#include <maya/MPlug.h>

#include <maya/MVector.h>
#include <maya/MMatrix.h>

#include "plugin.h"
#include "multiTrigger.h"


// --------------------------------------------------------------------------

MTypeId     multiTrigger::id( ID_MULTITRIGGER );		// Assigned by Alias

// --------------------------------------------------------------------------

/*
 * Static Attrs decl.
 */
// Input Attrs
MObject	multiTrigger::aInput ;				// Cmpd Inputs
MObject	multiTrigger::aEnvelope ;				// Basic overall envelope
MObject	multiTrigger::aTriggerMode ;		// How are we triggering output value?
MObject	multiTrigger::aInputValues ;		// Array of input values 

// Output Attrs
MObject multiTrigger::aOutWeight ;			// Output array of weight


// --------------------------------------------------------------------------

/*
 * multiTrigger::multiTrigger() - Constructor
 */
multiTrigger::multiTrigger() 
{
}

// --------------------------------------------------------------------------

/*
 * multiTrigger::~multiTrigger() - Destructor
 */
multiTrigger::~multiTrigger() 
{
}

// --------------------------------------------------------------------------

/*
 * multiTrigger::creator() - Alloc new node for Maya
 */
void* multiTrigger::creator()
{
	return new multiTrigger();
}

// --------------------------------------------------------------------------

/*
 * multiTrigger::initialize() - Setup attrs on node.
 *
 *	Return Values:
 *		MS::kSuccess
 *		MS::kFailure
 *		
 */
MStatus multiTrigger::initialize()
{
	MStatus				stat;
	
	MFnNumericAttribute nAttr ;
	MFnCompoundAttribute cAttr ;
	MFnEnumAttribute eAttr ;
	MFnMatrixAttribute mAttr ;
	MFnMessageAttribute msgAttr ;


	// Input Attrs
	//
	aEnvelope = nAttr.create( "envelope", "env", MFnNumericData::kFloat, 1.0 );
	nAttr.setSoftMin(0.0) ;
	nAttr.setSoftMax(1.0) ;
	nAttr.setKeyable(true);

	aTriggerMode = eAttr.create( "triggerMode", "tmod", 0) ;
	eAttr.addField("lowest", eTriggerLowest ) ;
	eAttr.addField("average", eTriggerAverage ) ;
	eAttr.addField("multiply", eTriggerMultiply ) ;
	eAttr.setKeyable(true) ;

	aInputValues = nAttr.create( "inputValues", "ival", MFnNumericData::kDouble, 1.0 );
	nAttr.setArray(true);
	nAttr.setUsesArrayDataBuilder(true) ;


	// Now make cmpd
	aInput = cAttr.create( "input", "inp" ) ;
	cAttr.addChild( aEnvelope ) ;
	cAttr.addChild( aTriggerMode ) ;
	cAttr.addChild( aInputValues ) ;





	// Output Attrs
	//
	aOutWeight = nAttr.create( "outWeight", "out", MFnNumericData::kDouble, 0.0 );
	nAttr.setWritable(false);

	// Add the attributes we have created to the node
	//

	stat = addAttribute( aInput );
		if (!stat) { stat.perror("addAttribute"); return stat;}

	stat = addAttribute( aOutWeight );
		if (!stat) { stat.perror("addAttribute"); return stat;}


	// Set up a dependency between the input and the output.  This will cause
	// the output to be marked dirty when the input changes.  The output will
	// then be recomputed the next time the value of the output is requested.
	//
	stat = attributeAffects( aInput, aOutWeight );
		if (!stat) { stat.perror("attributeAffects"); return stat;}

	return MS::kSuccess;

}

// --------------------------------------------------------------------------


/*
 * multiTrigger::compute() - Main calc
 */
MStatus multiTrigger::compute( const MPlug &plug, MDataBlock &data )
{
	MStatus stat;
 
	if( plug == aOutWeight )
		{
		MObject thisObject = thisMObject() ;


		// Read input values

		MDataHandle hEnvelope = data.inputValue( aEnvelope, &stat );
		float fEnv = hEnvelope.asFloat() ;

		MDataHandle hNodeState = data.inputValue( state, &stat );
		int nNodeState = hNodeState.asShort() ;
		

		if (fEnv == 0.0 || nNodeState == 1)		// For speed
			{
			MDataHandle hOutWeight = data.outputValue( aOutWeight );
			hOutWeight.set( 0.0 );
			hOutWeight.setClean() ;
			data.setClean( plug );
			return MS::kSuccess ;
			}

		MDataHandle hTriggerMode = data.inputValue( aTriggerMode, &stat );
		ETRIGGERMODE eTriggerMode = (ETRIGGERMODE)hTriggerMode.asShort() ;

		// Read in the value weights
		MDoubleArray dArrVals ;
		unsigned uVals ;
		stat = readInputValues(data, dArrVals, uVals) ;


		// ==========================================
		// Now do real calc
		
		unsigned u ;
		double dWt = 0.0 ;			// output weight

		// Now go thru each input weight...
		for (u=0; u < uVals; ++u)
			{
			if (u == 0)
				dWt = dArrVals[u] ;
			else
				{
				switch (eTriggerMode)
					{
					case eTriggerLowest:
						if (dArrVals[u] < dWt)
							dWt = dArrVals[u] ;
						break ;

					case eTriggerAverage:
						dWt += dArrVals[u] ;
						break ;

					case eTriggerMultiply:
						dWt *= dArrVals[u] ;
						break ;
					}
				}
			} // end of u loop


		if (eTriggerMode == eTriggerAverage && uVals > 0)
			dWt /= uVals ;		// Average now...


		// End of node calc
		// ==========================================


		// Set outputs
		MDataHandle hOutWeight = data.outputValue( aOutWeight );
		hOutWeight.set( dWt );
		hOutWeight.setClean() ;

		data.setClean( plug );
		} 
	else 
		{
		return MS::kUnknownParameter;
		}

	return MS::kSuccess;
}

// --------------------------------------------------------------------------

/*
 * multiTrigger::readInputValues() - Reads input values.
 */
MStatus multiTrigger::readInputValues(MDataBlock &data, MDoubleArray &dArrVals, unsigned &uVals)
{
	MStatus stat ;
	MArrayDataHandle hArrInputValues = data.inputArrayValue( aInputValues, &stat) ;
	uVals = hArrInputValues.elementCount(&stat) ;		// How many inputs?
	unsigned u ;

	dArrVals.setLength( uVals ) ;		// alloc array

	for (u=0; u < uVals; ++u)
		{
		MDataHandle hEleVal = hArrInputValues.inputValue(&stat) ;
		if (stat)
			dArrVals[u] = hEleVal.asDouble() ;
		
		stat = hArrInputValues.next() ;			// and go to next one.
		}

	return MS::kSuccess ;
}

// --------------------------------------------------------------------------
