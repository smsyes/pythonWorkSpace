// --------------------------------------------------------------------------
// poseReader.cpp - C++ File
// --------------------------------------------------------------------------
// Copyright �2004 Michael B. Comet  All Rights Reserved
// --------------------------------------------------------------------------
//
// DESCRIPTION:
//	File for poseReader node.
//
// AUTHORS:
//		Michael B. Comet - comet@comet-cartoons.com
//
// VERSIONS:
//		1.00 - 09/11/04 - comet - Initial Rev.
//		1.06 - 10/17/04 - comet - Moved over smooth/gaussian options here.
//					Brought up version to match with poseDeformer.
//					Now has animCuve mode.
//		1.08 - 11/16/04 - comet - Now does translate
//		1.09 - 11/17/04 - comet - Has multiTrigger support for better usage
//				of multiple nodes at once.  Also has allowRotate option.
//		1.10 - 01/21/05 - mcomet - Now has nodestate HasNoEffect stop.
//
// --------------------------------------------------------------------------
//
//  poseReader - Pose Space Angle Reader Maya Plugin by Michael B. Comet
//  Copyright �2004 Michael B. Comet
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//   For information on poseDeformer contact:
//			Michael B. Comet - comet@comet-cartoons.com
//			or visit http://www.comet-cartooons.com/toons/
//
// --------------------------------------------------------------------------

/*
 * Includes
 */
#include <math.h>

#include <maya/MPlug.h>
#include <maya/MDataBlock.h>
#include <maya/MDataHandle.h>
#include <maya/MFnDependencyNode.h>
#include <maya/MFnDagNode.h>

#include <maya/MFnNumericAttribute.h>
#include <maya/MFnCompoundAttribute.h>
#include <maya/MFnEnumAttribute.h>
#include <maya/MFnMatrixAttribute.h>
#include <maya/MFnMessageAttribute.h>

#include <maya/MPlug.h>
#include <maya/MPlugArray.h>
#include <maya/MFnAnimCurve.h>

#include <maya/MVector.h>
#include <maya/MMatrix.h>
#include <maya/MColor.h>

#include "plugin.h"
#include "poseReader.h"


// --------------------------------------------------------------------------

MTypeId     poseReader::id( ID_POSEREADER );		// Assigned by Alias

// --------------------------------------------------------------------------

/*
 * Static Attrs decl.
 */
MObject	poseReader::aPoseData ;				// Array Compound of input data
MObject	poseReader::aWorldMatrixLiveIn ;		// mat for real jnt
MObject	poseReader::aWorldMatrixPoseIn ;		// mat for pose loc
MObject	poseReader::aMsgAnimCurve ;			// Msg attr from an animCurve.
MObject	poseReader::aAnimCurveOutput ;		// Output from animCurve.
MObject	poseReader::aReadAxis ;				// Enum of what axis, x,y,z,all to read?
MObject	poseReader::aInterpMode ;			// How to interpolate from 0-180...
MObject	poseReader::aAllowRotate ;			// 0-1 allowing of rotate or not.
MObject	poseReader::aMinAngle ;				// Anything in here is one default 0
MObject	poseReader::aMaxAngle ;				// up to here... default 180
MObject	poseReader::aAllowTwist ;			// 0-1 allowing of twist or not.
MObject	poseReader::aMinTwist ;				// Min Twist allowed
MObject	poseReader::aMaxTwist ;				// Max Twist allowed
MObject	poseReader::aAllowTranslate ;		// If on, translate anywhere is allowed.
MObject	poseReader::aMinTranslate ;			// Min Translate allowed
MObject	poseReader::aMaxTranslate ;			// Max Translate allowed

MObject	poseReader::aDrawData ;				// Compound of drawing options
MObject	poseReader::aDrawDetail ;			// Detail level of drawing.
MObject	poseReader::aDrawCone ;				// Text cone options
MObject	poseReader::aDrawText ;				// Text draw options
MObject	poseReader::aDrawReverse ;			// For joints where the axis is backwards, you may want this.
MObject	poseReader::aDrawHighlight ;		// Change to maya sel colors when selected?

MObject poseReader::aOutWeight ;			// Output array of weight


// --------------------------------------------------------------------------

/*
 * poseReader::poseReader() - Constructor
 */
poseReader::poseReader() 
{
}

// --------------------------------------------------------------------------

/*
 * poseReader::~poseReader() - Destructor
 */
poseReader::~poseReader() 
{
}

// --------------------------------------------------------------------------

/*
 * poseReader::creator() - Alloc new node for Maya
 */
void* poseReader::creator()
{
	return new poseReader();
}

// ---------------------------------------------------------------------------

/*
 * ccMuscleDisplay::isBounded - Do we have our own bounding box?
 */
bool poseReader::isBounded() const
{ 
	return false ;
}

// --------------------------------------------------------------------------

/*
 * poseReader::initialize() - Setup attrs on node.
 *
 *	Return Values:
 *		MS::kSuccess
 *		MS::kFailure
 *		
 */
MStatus poseReader::initialize()
{
	MStatus				stat;
	
	MFnNumericAttribute nAttr ;
	MFnCompoundAttribute cAttr ;
	MFnEnumAttribute eAttr ;
	MFnMatrixAttribute mAttr ;
	MFnMessageAttribute msgAttr ;


	// Input Attrs
	//
	aWorldMatrixLiveIn = mAttr.create( "worldMatrixLiveIn", "wml" ) ;
	aWorldMatrixPoseIn = mAttr.create( "worldMatrixPoseIn", "wmp" ) ;

	aMsgAnimCurve = msgAttr.create("msgAnimCurve", "msgac");

	aAnimCurveOutput = nAttr.create( "animCurveOutput", "acout", MFnNumericData::kDouble, 1.0 );

	aReadAxis = eAttr.create( "readAxis", "axi", 1) ;
	eAttr.addField("X-Axis", 0) ;
	eAttr.addField("Y-Axis", 1) ;
	eAttr.addField("Z-Axis", 2) ;
	eAttr.setKeyable(true) ;

	aInterpMode = eAttr.create( "interpMode", "imod", eInterpSmoothStep ) ;
	eAttr.addField("Linear", eInterpLinear ) ;
	eAttr.addField("SmoothStep", eInterpSmoothStep ) ;
	eAttr.addField("Gaussian", eInterpGaussian ) ;
	eAttr.addField("AnimCurve", eInterpCurve ) ;
	eAttr.setKeyable(true) ;

	aAllowRotate = nAttr.create( "allowRotate", "aro", MFnNumericData::kDouble, 0.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(1.0) ;
	nAttr.setKeyable(true) ;

	aMinAngle = nAttr.create( "minAngle", "min", MFnNumericData::kDouble, 0.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(180.0) ;
	nAttr.setKeyable(true) ;

	aMaxAngle = nAttr.create( "maxAngle", "max", MFnNumericData::kDouble, 180.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(180.0) ;
	nAttr.setKeyable(true) ;

	aAllowTwist = nAttr.create( "allowTwist", "atw", MFnNumericData::kDouble, 1.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(1.0) ;
	nAttr.setKeyable(true) ;

	aMinTwist = nAttr.create( "minTwist", "mtw", MFnNumericData::kDouble, 0.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(180.0) ;
	nAttr.setKeyable(true) ;

	aMaxTwist = nAttr.create( "maxTwist", "xtw", MFnNumericData::kDouble, 180.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(180.0) ;
	nAttr.setKeyable(true) ;

	aAllowTranslate = nAttr.create( "allowTranslate", "atr", MFnNumericData::kDouble, 1.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(1.0) ;
	nAttr.setKeyable(true) ;

	aMinTranslate = nAttr.create( "minTranslate", "mtr", MFnNumericData::kDouble, 0.0 );
	nAttr.setMin(0.0) ;
	nAttr.setKeyable(true) ;

	aMaxTranslate = nAttr.create( "maxTranslate", "xtr", MFnNumericData::kDouble, 1.0 );
	nAttr.setMin(0.0) ;
	nAttr.setKeyable(true) ;


	// Now make cmpd
	aPoseData = cAttr.create( "poseData", "data" ) ;
	cAttr.addChild( aWorldMatrixLiveIn ) ;
	cAttr.addChild( aWorldMatrixPoseIn ) ;
	cAttr.addChild( aMsgAnimCurve ) ;
	cAttr.addChild( aAnimCurveOutput ) ;
	cAttr.addChild( aReadAxis ) ;
	cAttr.addChild( aInterpMode ) ;
	cAttr.addChild( aAllowRotate ) ;
	cAttr.addChild( aMinAngle ) ;
	cAttr.addChild( aMaxAngle ) ;
	cAttr.addChild( aAllowTwist ) ;
	cAttr.addChild( aMinTwist ) ;
	cAttr.addChild( aMaxTwist ) ;
	cAttr.addChild( aAllowTranslate ) ;
	cAttr.addChild( aMinTranslate ) ;
	cAttr.addChild( aMaxTranslate ) ;


	aDrawDetail = nAttr.create( "drawDetail", "det", MFnNumericData::kInt, 14.0 );
	nAttr.setMin(0) ;
	nAttr.setMax(48) ;
	nAttr.setKeyable(true) ;

	aDrawCone = eAttr.create("drawCone", "con", 2 ) ;
	eAttr.addField( "off", 0) ;
	eAttr.addField( "on", 1) ;
	eAttr.addField( "selected", 2) ;
	eAttr.setKeyable(true) ;

	aDrawText = eAttr.create("drawText", "txt", 2 ) ;
	eAttr.addField( "off", 0) ;
	eAttr.addField( "on", 1) ;
	eAttr.addField( "selected", 2) ;
	eAttr.setKeyable(true) ;

	aDrawHighlight = nAttr.create( "drawHighlight", "dhi", MFnNumericData::kFloat, 1.0 );
	nAttr.setMin(0.0) ;
	nAttr.setMax(1.0) ;
	nAttr.setKeyable(true) ;

	aDrawReverse = nAttr.create( "drawReverse", "drv", MFnNumericData::kBoolean, 0 );
	nAttr.setKeyable(true) ;

	aDrawData = cAttr.create( "drawData", "ddat" ) ;
	cAttr.addChild( aDrawDetail ) ;
	cAttr.addChild( aDrawCone ) ;
	cAttr.addChild( aDrawText ) ;
	cAttr.addChild( aDrawReverse ) ;
	cAttr.addChild( aDrawHighlight ) ;



	// Output Attrs
	//
	aOutWeight = nAttr.create( "outWeight", "out", MFnNumericData::kDouble, 0.0 );
	nAttr.setWritable(false);

	// Add the attributes we have created to the node
	//

	stat = addAttribute( aPoseData );
		if (!stat) { stat.perror("addAttribute"); return stat;}
	stat = addAttribute( aDrawData );
		if (!stat) { stat.perror("addAttribute"); return stat;}

	stat = addAttribute( aOutWeight );
		if (!stat) { stat.perror("addAttribute"); return stat;}


	// Set up a dependency between the input and the output.  This will cause
	// the output to be marked dirty when the input changes.  The output will
	// then be recomputed the next time the value of the output is requested.
	//
	stat = attributeAffects( aPoseData, aOutWeight );
		if (!stat) { stat.perror("attributeAffects"); return stat;}

	return MS::kSuccess;

}

// --------------------------------------------------------------------------


/*
 * poseReader::compute() - Main calc
 */
MStatus poseReader::compute( const MPlug &plug, MDataBlock &data )
{
	MStatus stat;
 
	if( plug == aOutWeight )
		{
		MObject thisObject = thisMObject() ;

		// Just stop if we in a "HasNoEffect" node state...
		MDataHandle hNodeState = data.inputValue( state, &stat) ;
		int nNodeState = hNodeState.asShort() ;
		if (nNodeState == 1)
			return MS::kSuccess ;


		// Read input values
		MDataHandle hWorldMatrixLiveIn = data.inputValue( aWorldMatrixLiveIn, &stat );
		MMatrix matLive = hWorldMatrixLiveIn.asMatrix();
		MMatrix invmatLive = matLive.inverse() ;

		MDataHandle hWorldMatrixPoseIn = data.inputValue( aWorldMatrixPoseIn, &stat );
		MMatrix matPose = hWorldMatrixPoseIn.asMatrix();
		MMatrix invmatPose = matPose.inverse() ;

		MDataHandle hReadAxis = data.inputValue( aReadAxis, &stat );
		int nReadAxis = hReadAxis.asShort() ;

		MDataHandle hInterpMode = data.inputValue( aInterpMode, &stat );
		int nInterpMode = hInterpMode.asShort() ;
		

		MDataHandle hAllowRotate = data.inputValue( aAllowRotate, &stat );
		double dAllowRotate = hAllowRotate.asDouble() ;

		MDataHandle hMinAngle = data.inputValue( aMinAngle, &stat );
		double dMinAngle = hMinAngle.asDouble() ;

		MDataHandle hMaxAngle = data.inputValue( aMaxAngle, &stat );
		double dMaxAngle = hMaxAngle.asDouble() ;

		if (dMinAngle >= dMaxAngle)
			dMinAngle = dMaxAngle-0.001 ;

		MDataHandle hAllowTwist = data.inputValue( aAllowTwist, &stat );
		double dAllowTwist = hAllowTwist.asDouble() ;

		MDataHandle hMinTwist = data.inputValue( aMinTwist, &stat );
		double dMinTwist = hMinTwist.asDouble() ;

		MDataHandle hMaxTwist = data.inputValue( aMaxTwist, &stat );
		double dMaxTwist = hMaxTwist.asDouble() ;

		if (dMinTwist >= dMaxTwist)
			dMinTwist = dMaxTwist-0.001 ;


		MDataHandle hAllowTranslate = data.inputValue( aAllowTranslate, &stat );
		double dAllowTranslate = hAllowTranslate.asDouble() ;

		MDataHandle hMinTranslate = data.inputValue( aMinTranslate, &stat );
		double dMinTranslate = hMinTranslate.asDouble() ;

		MDataHandle hMaxTranslate = data.inputValue( aMaxTranslate, &stat );
		double dMaxTranslate = hMaxTranslate.asDouble() ;

		if (dMinTranslate >= dMaxTranslate)
			dMinTranslate = dMaxTranslate-0.001 ;


		// Get anim curve function set...
		//
		// Get a plug to msg attr
		MPlug plugMsgAnimCurve(thisObject, aMsgAnimCurve) ;
		MPlugArray plugArrMsgACIn ;			// What is connected into it?
		MObject oAnimCurve ;
		plugMsgAnimCurve.connectedTo( plugArrMsgACIn, true, false, &stat) ;
		if (plugArrMsgACIn.length() > 0)		// If something is connected
			{
			MPlug plugInput = plugArrMsgACIn[0] ;	// get the node on the opposite side
			oAnimCurve = plugInput.node(&stat) ;
			}
		MFnAnimCurve fnAnimCurve(oAnimCurve, &stat) ;
		bool bHasAC ;
		if (!stat || fnAnimCurve.animCurveType(&stat) != MFnAnimCurve::kAnimCurveUU)
			bHasAC = false ;
		else
			bHasAC = true ;




		// ==========================================
		// Now do real calc
		
		double dWt = 1.0 ;			// output weight

		double dDot = -1.0 ;
		double dAngle = 180.0;
		double dWtTwist = 1.0 ;
		double dWtTranslate = 1.0 ;

		MMatrix matRelPose = matLive * invmatPose ;		// where is joint relative to pose node?

		if (nReadAxis == 0)		// X-Axis
			{
				// Get X axis of live joint in relative space of the pose node.
			MVector vAxis = MVector(1,0,0) * matRelPose ;
			vAxis.normalize() ;
			dDot = vAxis * MVector(1,0,0) ;		// Now in pose space, compare it's X axis to the joint
			if (dDot >= 1.0)		// Have to do this to handle precision errors in acos returning -1.#IND
				dAngle = 0.0 ;
			else if (dDot <= -1.0)
				dAngle = 180.0 ;
			else
				dAngle = acos(dDot) * VRADTODEG;	// Now what is actual angle in degress?

			dWt = calcWtFromAngle(dAngle, dMinAngle, dMaxAngle) ;
			dWt = ((1.0-dAllowRotate) * dWt) + (dAllowRotate * 1.0) ;

			if (dAllowTwist != 1.0)
				{
				MVector vAxisTwist = MVector(0,1,0) * matRelPose ;
				vAxisTwist.normalize() ;
				double dDotTwist = vAxisTwist * MVector(0,1,0) ;
				double dAngleTwist ;			
				if (dDotTwist >= 1.0)
					dAngleTwist = 0.0 ;
				else if (dDotTwist <= -1.0)
					dAngleTwist = 180.0 ;
				else
					dAngleTwist = acos(dDotTwist) * VRADTODEG;	// Now what is actual angle in degress?
			
				dWtTwist = calcWtFromAngle(dAngleTwist, dMinTwist, dMaxTwist) ;

				dWt = ((1.0-dAllowTwist)*(dWt * dWtTwist)) + (dAllowTwist * dWt) ;
				}
			}
		else if (nReadAxis == 1)	// Y-Axis
			{
				// Get Y axis of live joint in relative space of the pose node.
			MVector vAxis = MVector(0,1,0) * matRelPose ;
			vAxis.normalize() ;
			dDot = vAxis * MVector(0,1,0) ;		// Now in pose space, compare it's Y axis to the joint
			if (dDot >= 1.0)		// Have to do this to handle precision errors in acos returning -1.#IND
				dAngle = 0.0 ;
			else if (dDot <= -1.0)
				dAngle = 180.0 ;
			else
				dAngle = acos(dDot) * VRADTODEG;	// Now what is actual angle in degress?
			
			dWt = calcWtFromAngle(dAngle, dMinAngle, dMaxAngle) ;
			dWt = ((1.0-dAllowRotate) * dWt) + (dAllowRotate * 1.0) ;

		//cout << "dWt=" << dWt << " dAngle=" << dAngle << " acos(dDot)=" << acos(dDot) << " dAllowTwist=" << dAllowTwist << " dDot=" << dDot << " vAxis=" << vAxis << " dMinAngle=" << dMinAngle << " dMaxAngle=" << dMaxAngle << endl ;
			
			if (dAllowTwist != 1.0)
				{
				MVector vAxisTwist = MVector(1,0,0) * matRelPose ;
				vAxisTwist.normalize() ;
				double dDotTwist = vAxisTwist * MVector(1,0,0) ;
				double dAngleTwist ;			
				if (dDotTwist >= 1.0)
					dAngleTwist = 0.0 ;
				else if (dDotTwist <= -1.0)
					dAngleTwist = 180.0 ;
				else
					dAngleTwist = acos(dDotTwist) * VRADTODEG;	// Now what is actual angle in degress?
			
				dWtTwist = calcWtFromAngle(dAngleTwist, dMinTwist, dMaxTwist) ;

				dWt = ((1.0-dAllowTwist)*(dWt * dWtTwist)) + (dAllowTwist * dWt) ;
				}
			}
		else if (nReadAxis == 2)	// Z-Axis
			{
				// Get Z axis of live joint in relative space of the pose node.
			MVector vAxis = MVector(0,0,1) * matRelPose ;
			vAxis.normalize() ;
			dDot = vAxis * MVector(0,0,1) ;		// Now in pose space, compare it's Z axis to the joint
			if (dDot >= 1.0)		// Have to do this to handle precision errors in acos returning -1.#IND
				dAngle = 0.0 ;
			else if (dDot <= -1.0)
				dAngle = 180.0 ;
			else
				dAngle = acos(dDot) * VRADTODEG;	// Now what is actual angle in degress?

			dWt = calcWtFromAngle(dAngle, dMinAngle, dMaxAngle) ;
			dWt = ((1.0-dAllowRotate) * dWt) + (dAllowRotate * 1.0) ;

			if (dAllowTwist != 1.0)
				{
				MVector vAxisTwist = MVector(1,0,0) * matRelPose ;
				vAxisTwist.normalize() ;
				double dDotTwist = vAxisTwist * MVector(1,0,0) ;
				double dAngleTwist ;			
				if (dDotTwist >= 1.0)
					dAngleTwist = 0.0 ;
				else if (dDotTwist <= -1.0)
					dAngleTwist = 180.0 ;
				else
					dAngleTwist = acos(dDotTwist) * VRADTODEG;	// Now what is actual angle in degress?
			
				dWtTwist = calcWtFromAngle(dAngleTwist, dMinTwist, dMaxTwist) ;

				dWt = ((1.0-dAllowTwist)*(dWt * dWtTwist)) + (dAllowTwist * dWt) ;
				}
			}

		if (dAllowTranslate != 1.0)
			{
			MVector vTrans( matRelPose[3][0], matRelPose[3][1], matRelPose[3][2] ) ;
			double dDist = vTrans.length() ;
			if (dDist <= dMinTranslate)
                dWtTranslate = 1.0 ;
			else if (dDist >= dMaxTranslate)
                dWtTranslate = 0.0 ;
			else
				{
                dWtTranslate = 1.0 - ((dDist - dMinTranslate) / (dMaxTranslate - dMinTranslate)) ;
				}

			dWt = ((1.0-dAllowTranslate)*(dWt * dWtTranslate)) + (dAllowTranslate * dWt) ;
			}


			// Adjust actual output a bit if desired.
		if (nInterpMode == eInterpLinear)
			;
		else if (nInterpMode == eInterpSmoothStep)
			dWt = smoothStep(dWt) ;
		else if (nInterpMode == eInterpGaussian)
			dWt = smoothGaussian(dWt) ;
		else if (nInterpMode ==	eInterpCurve)
			{
			if (!bHasAC)
				MGlobal::displayWarning(name()+MString(": You must connect an animCurveUU node into the msgAnimCurve attribute to use animCurve interpolation features.")) ;
			else
				{
				double dAtX = 1.0 - dWt ;
				
				MPlug plugInput = fnAnimCurve.findPlug("input", &stat) ;	// Mmm sometimes going outside the DAG is good...or it's good to be bad...
				plugInput.setValue(dAtX) ;	// Do this so we wake up the curve...and then us again.

				MDataHandle hAnimCurveOutput = data.inputValue(aAnimCurveOutput, &stat) ;
				double dOutput = hAnimCurveOutput.asDouble() ;
//				cout << "dOutput=" << dOutput << endl ;

				dWt = dOutput ;		// Could do commented out code below, but since we are using in/out to actually drive stuff, just use that anyhow...
//				fnAnimCurve.evaluate(dAtX, dWt) ;		// Whatever 0-1 we are at, get real value from curve.
				}
			}



		// End of node calc
		// ==========================================


		// Set outputs
		MDataHandle hOutWeight = data.outputValue( aOutWeight );
		hOutWeight.set( dWt );
		hOutWeight.setClean() ;

		data.setClean( plug );
		} 
	else 
		{
		return MS::kUnknownParameter;
		}

	return MS::kSuccess;
}

// --------------------------------------------------------------------------


/*
 * poseReader::calcWtFromAngle() - Calcs weight based on a 0-180 angle.
 */
double poseReader::calcWtFromAngle(const double& dAngle, const double& dMinAngle, const double& dMaxAngle)
{
	double dWt ;

	if (dAngle >= dMaxAngle)
		dWt = 0.0 ;
	else if (dAngle <= dMinAngle)
		dWt = 1.0 ;
	else
		{
		double dDelta = dMaxAngle - dMinAngle ;
		if (dDelta > 0)
			dWt = 1.0 - ((dAngle - dMinAngle) / dDelta) ;
		else
			dWt = 0.0 ;
		}

	return dWt ;
}

// ---------------------------------------------------------------------------


/*
 * poseReader::smoothStep() - Take a value from 0-1 and instead of having it be linear,
 *			make it ease out and then in from the 0 and 1 locations.
 */
double poseReader::smoothStep(const double &dVal)
{
	// x^2*(3-2x)
	double dRet = dVal * dVal * (3.0 - (2.0 * dVal) );
	return dRet ;
}

// ---------------------------------------------------------------------------

/*
 * poseReader::smoothGaussian() - Take a value from 0-1 and instead of having it be linear,
 *			make it ease out and then in from the 0 and 1 locations.  This has more of a longer
 *			ease than a smoothstep and so a faster falloff in the middle.
 */
double poseReader::smoothGaussian(const double &dVal)
{
	// 1.0 - exp( (-1 * x^2 ) / (2*sigma^2) )
	
	double dSigma = 1.0 ;		// Must be >0.   As drops to zero, higher value one lasts longer.

	double dRet = (1.0 - exp( -1.0 * (dVal*dVal) * 10.0  / (2.0 * dSigma*dSigma)  ) );	// RBF
	return dRet ;
}


/*
 * poseReader::draw() - Draw routine
 */
void poseReader::draw( M3dView & view, const MDagPath & path, 
							 M3dView::DisplayStyle dispStyle,
							 M3dView::DisplayStatus status )
{ 
    MStatus stat ;


	// Get the attrs needed
    //
    MObject thisNode = thisMObject();
//	MFnDependencyNode depThis( thisNode ) ;
//	MString name = depThis.name() ;
	MFnDagNode dagThis( thisNode ) ;
	MString name = dagThis.name() ; 
	MObject oParent = dagThis.parent(0, &stat) ;
	MFnDagNode dagParent( oParent ) ;
	MString nameParent = dagParent.name() ; 


	MPlug plugDrawDetail( thisNode, aDrawDetail) ;
	int nDrawDetail ;
	plugDrawDetail.getValue( nDrawDetail ) ;

		// If set to zero, means no drawing at all!
	if (nDrawDetail == 0)
		return ;

	MPlug plugDrawCone( thisNode, aDrawCone) ;
	int nDrawCone ;
	plugDrawCone.getValue( nDrawCone ) ;

	MPlug plugDrawText( thisNode, aDrawText) ;
	int nDrawText ;
	plugDrawText.getValue( nDrawText ) ;

	MPlug plugDrawReverse( thisNode, aDrawReverse) ;
	bool bDrawReverse ;
	plugDrawReverse.getValue( bDrawReverse ) ;


	MPlug plugDrawHighlight( thisNode, aDrawHighlight) ;
	float fDrawHighlight ;
	plugDrawHighlight.getValue( fDrawHighlight ) ;


	MPlug plugOutWeight( thisNode, aOutWeight) ;
	double dOutWeight ;
	plugOutWeight.getValue( dOutWeight ) ;

	MPlug plugReadAxis( thisNode, aReadAxis) ;
	int nReadAxis ;
	plugReadAxis.getValue( nReadAxis ) ;

	MPlug plugAllowTwist( thisNode, aAllowTwist) ;
	double dAllowTwist ;
	plugAllowTwist.getValue( dAllowTwist ) ;

	MPlug plugAllowRotate( thisNode, aAllowRotate) ;
	double dAllowRotate ;
	plugAllowRotate.getValue( dAllowRotate ) ;

	MPlug plugMinAngle( thisNode, aMinAngle) ;
	double dMinAngle ;
	plugMinAngle.getValue( dMinAngle ) ;

	MPlug plugMaxAngle( thisNode, aMaxAngle) ;
	double dMaxAngle ;
	plugMaxAngle.getValue( dMaxAngle ) ;

	if (dMinAngle >= dMaxAngle)
		dMinAngle = dMaxAngle-0.001 ;


	MPlug plugAllowTranslate( thisNode, aAllowTranslate) ;
	double dAllowTranslate ;
	plugAllowTranslate.getValue( dAllowTranslate ) ;

	MPlug plugMinTranslate( thisNode, aMinTranslate) ;
	double dMinTranslate ;
	plugMinTranslate.getValue( dMinTranslate ) ;

	MPlug plugMaxTranslate( thisNode, aMaxTranslate) ;
	double dMaxTranslate ;
	plugMaxTranslate.getValue( dMaxTranslate ) ;

	if (dMinTranslate >= dMaxTranslate)
		dMinTranslate = dMaxTranslate-0.001 ;


	// End of getting attrs
    bool bShaded = false ;
		// now even if we want shaded...if we are not in a shaded mode, de-activate it!
	if ( dispStyle != M3dView::kFlatShaded && dispStyle != M3dView::kGouraudShaded ) 
	    bShaded = false ;


	// Figure override color
	MColor colO ;
	bool bColOverride = false ;
	bool bSel = false ;	// are we selected?

	// And now a few overrides for selection, last selection or
	//	template... So make nice colors
	//
	switch (status)  // From M3dView::DisplayStatus status  in the draw() command
	    {
		case M3dView::kLead:
	        colO = MColor(0.26f, 1.0f, 0.64f)  ;		// maya green
	        bColOverride = true;
			bSel = true ;
	        break ;

		case M3dView::kActive:
	        colO = MColor(1.0f, 1.0f, 1.0f)  ;		// maya white
	        bColOverride = true;
			bSel = true ;
			break ;
	    
		case M3dView::kActiveAffected:
	        colO = MColor(0.78f, 1.0f, 0.78f)  ;	// maya magenta
	        bColOverride = true;
	        break ;

		case M3dView::kTemplate:
	        colO = MColor(0.47f, 0.47f, 0.47f)  ;	// maya template gray
	        bColOverride = true;
	        break ;

		case M3dView::kActiveTemplate:
	        colO = MColor(1.0f, 0.47f, 0.47f)  ;	// maya selected template pink
	        bColOverride = true;
			break ;

	    default:
	        colO = MColor(0.1f, 0.2f, 0.7f) ;	// else set color as desired
			fDrawHighlight = 0.0f ;		// If default, then set highlght to 0 so always do user color.
			break ;
	    }




	view.beginGL(); 	// Start openGL

			// Push the color settings
	glPushAttrib( GL_CURRENT_BIT | GL_POINT_BIT  | GL_LINE_BIT ) ;
	glBegin( GL_LINES );

	view.setDrawColor( colO );	// Set color as desired

	double dHead = 0.1 ; 
	int nSegs = nDrawDetail + 1 ;
	double dNeg = 1.0 ;
	if (bDrawReverse)
		dNeg = -1.0 ;

	// First draw X-Axis
	if (nReadAxis == 0 || dAllowTwist != 1.0)
		{
		view.setDrawColor( blendColor(MColor(1.0f, 0.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired
			

			// Shaft
		glVertex3d( 0.0, 0.0, 0.0) ;
		glVertex3d( 1.0*dNeg, 0.0, 0.0) ;

		if (nReadAxis == 0 && nDrawDetail >= 2)
			{

				// Head
			glVertex3d( (1.0+dHead)*dNeg, 0.0, 0.0) ;
			glVertex3d( 1.0*dNeg, (dHead/2.0), (dHead/2.0)) ;

			glVertex3d( (1.0+dHead)*dNeg, 0.0, 0.0) ;
			glVertex3d( 1.0*dNeg, (dHead/2.0), -(dHead/2.0)) ;

			glVertex3d( (1.0+dHead)*dNeg, 0.0, 0.0) ;
			glVertex3d( 1.0*dNeg, -(dHead/2.0), -(dHead/2.0)) ;

			glVertex3d( (1.0+dHead)*dNeg, 0.0, 0.0) ;
			glVertex3d( 1.0*dNeg, -(dHead/2.0), (dHead/2.0)) ;
			
				// Base square of head
			glVertex3d( 1.0*dNeg, (dHead/2.0), (dHead/2.0)) ;
			glVertex3d( 1.0*dNeg, (dHead/2.0), -(dHead/2.0)) ;

			glVertex3d( 1.0*dNeg, (dHead/2.0), -(dHead/2.0)) ;
			glVertex3d( 1.0*dNeg, -(dHead/2.0), -(dHead/2.0)) ;

			glVertex3d( 1.0*dNeg, -(dHead/2.0), -(dHead/2.0)) ;
			glVertex3d( 1.0*dNeg, -(dHead/2.0), (dHead/2.0)) ;

			glVertex3d( 1.0*dNeg, -(dHead/2.0), (dHead/2.0)) ;
			glVertex3d( 1.0*dNeg, (dHead/2.0), (dHead/2.0)) ;
			}

		if (nDrawCone == 1 || (nDrawCone == 2 && bSel))
			{
			if (nReadAxis == 0 && nDrawDetail >= 3 && dAllowRotate != 1.0)
				{
				view.setDrawColor( blendColor(MColor(0.8f, 0.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired

					// Draw MAX Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				double dLen = dNeg * cos(dMaxAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				double dRad = sin(dMaxAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				// Now draw circle
				int i;
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( dLen, a, b ) ;

					glVertex3d( dLen, a, b ) ;
					glVertex3d( dLen, a2, b2 ) ;
					}


					// Draw MIN Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				dLen = dNeg * cos(dMinAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				dRad = sin(dMinAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				view.setDrawColor( blendColor(MColor(1.0f, 0.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired
				
				// Now draw circle
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( dLen, a, b ) ;

					glVertex3d( dLen, a, b ) ;
					glVertex3d( dLen, a2, b2 ) ;
					}
				}
			} //end of if draw cone x

		}	// End of Draw X
	

	// Draw Y-Axis
	if (nReadAxis == 1 || dAllowTwist != 1.0)
		{
		view.setDrawColor( blendColor(MColor(0.0f, 1.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired


			// Shaft
		glVertex3d( 0.0, 0.0, 0.0) ;
		glVertex3d( 0.0, 1.0*dNeg, 0.0) ;

		if (nReadAxis == 1 && nDrawDetail >= 2)
			{

				// Head
			glVertex3d( 0.0, (1.0+dHead)*dNeg, 0.0) ;
			glVertex3d( (dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;

			glVertex3d( 0.0, (1.0+dHead)*dNeg, 0.0) ;
			glVertex3d( (dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;

			glVertex3d( 0.0, (1.0+dHead)*dNeg, 0.0) ;
			glVertex3d( -(dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;

			glVertex3d( 0.0, (1.0+dHead)*dNeg, 0.0) ;
			glVertex3d( -(dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;
			
				// Base square of head
			glVertex3d( (dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;
			glVertex3d( (dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;

			glVertex3d( (dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;
			glVertex3d( -(dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;

			glVertex3d( -(dHead/2.0), 1.0*dNeg, -(dHead/2.0)) ;
			glVertex3d( -(dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;

			glVertex3d( -(dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;
			glVertex3d( (dHead/2.0), 1.0*dNeg, (dHead/2.0)) ;
			}

		if (nDrawCone == 1 || (nDrawCone == 2 && bSel))
			{
			if (nReadAxis == 1 && nDrawDetail >= 3 && dAllowRotate != 1.0)
				{
				view.setDrawColor( blendColor(MColor(0.0f, 0.8f, 0.0f), colO, fDrawHighlight) );	// Set color as desired

					// Draw MAX Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				double dLen = dNeg * cos(dMaxAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				double dRad = sin(dMaxAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				// Now draw circle
				int i;
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( a, dLen, b ) ;

					glVertex3d( a, dLen, b ) ;
					glVertex3d( a2, dLen, b2 ) ;
					}


					// Draw MIN Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				dLen = dNeg * cos(dMinAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				dRad = sin(dMinAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				view.setDrawColor( blendColor(MColor(0.0f, 1.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired
				
				// Now draw circle
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( a, dLen, b ) ;

					glVertex3d( a, dLen, b ) ;
					glVertex3d( a2, dLen, b2 ) ;
					}
				}
			} // end of draw Y cone

		}	// End of draw Y


	// Draw Z-Axis
	if (nReadAxis == 2 || dAllowTwist != 1.0)
		{
		view.setDrawColor( blendColor(MColor(0.0f, 0.0f, 1.0f), colO, fDrawHighlight) );	// Set color as desired


			// Shaft
		glVertex3d( 0.0, 0.0, 0.0) ;
		glVertex3d( 0.0, 0.0, 1.0*dNeg) ;

		if (nReadAxis == 2 && nDrawDetail >= 2)
			{

				// Head
			glVertex3d( 0.0, 0.0, (1.0+dHead)*dNeg) ;
			glVertex3d( (dHead/2.0), (dHead/2.0), 1.0*dNeg) ;

			glVertex3d( 0.0, 0.0, (1.0+dHead)*dNeg) ;
			glVertex3d( (dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;

			glVertex3d( 0.0, 0.0, (1.0+dHead)*dNeg) ;
			glVertex3d( -(dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;

			glVertex3d( 0.0, 0.0, (1.0+dHead)*dNeg) ;
			glVertex3d( -(dHead/2.0), (dHead/2.0), 1.0*dNeg) ;
			
				// Base square of head
			glVertex3d( (dHead/2.0), (dHead/2.0), 1.0*dNeg) ;
			glVertex3d( (dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;

			glVertex3d( (dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;
			glVertex3d( -(dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;

			glVertex3d( -(dHead/2.0), -(dHead/2.0), 1.0*dNeg) ;
			glVertex3d( -(dHead/2.0), (dHead/2.0), 1.0*dNeg) ;

			glVertex3d( -(dHead/2.0), (dHead/2.0), 1.0*dNeg) ;
			glVertex3d( (dHead/2.0), (dHead/2.0), 1.0*dNeg) ;
			}

		if (nDrawCone == 1 || (nDrawCone == 2 && bSel))
			{
			if (nReadAxis == 2 && nDrawDetail >= 3 && dAllowRotate != 1.0)
				{
				view.setDrawColor( blendColor(MColor(0.0f, 0.0f, 0.8f), colO, fDrawHighlight) );	// Set color as desired


					// Draw MAX Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				double dLen = dNeg * cos(dMaxAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				double dRad = sin(dMaxAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				// Now draw circle
				int i;
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( a, b, dLen ) ;

					glVertex3d( a, b, dLen ) ;
					glVertex3d( a2, b2, dLen ) ;
					}


					// Draw MIN Circle
					// Figure where down primary axis the circle will be drawn
					// and also the radius at the point.
					//
				dLen = dNeg * cos(dMinAngle/180.0*3.14159) ;	// As angle from 0..180, dLen= 1.0..-1.0
				dRad = sin(dMinAngle/180.0*3.14159) ;	// As angle from 0..90..180, dRad=0.0...1.0...0.0

				view.setDrawColor( blendColor(MColor(0.0f, 0.0f, 1.0f), colO, fDrawHighlight) );	// Set color as desired
				
				// Now draw circle
				for (i=0; i < nSegs; ++i)
					{
					double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
					double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
					double a = dRad * cos(dPct) ;
					double b = dRad * sin(dPct) ;
					double a2 = dRad * cos(dPct2) ;
					double b2 = dRad * sin(dPct2) ;

					glVertex3d( 0.0, 0.0, 0.0 ) ;
					glVertex3d( a, b, dLen ) ;

					glVertex3d( a, b, dLen ) ;
					glVertex3d( a2, b2, dLen ) ;
					}
				}
			} // end of draw z cone

		}	// end of draw Z


	// Draw Translate
	if (dAllowTranslate != 1.0 && (nDrawCone == 1 || (nDrawCone == 2 && bSel)) )
		{
		int i ;
		view.setDrawColor( blendColor(MColor(1.0f, 0.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired

				// Draw MIN Sphere
				//
		double dRad = dMinTranslate ;
		for (i=0; i < nSegs; ++i)
			{
			double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
			double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
			double a = dRad * cos(dPct) ;
			double b = dRad * sin(dPct) ;
			double a2 = dRad * cos(dPct2) ;
			double b2 = dRad * sin(dPct2) ;
			glVertex3d( a, b, 0 ) ;
			glVertex3d( a2, b2, 0 ) ;

			glVertex3d( 0, a, b ) ;
			glVertex3d( 0, a2, b2 ) ;

			glVertex3d( a, 0, b ) ;
			glVertex3d( a2, 0, b2 ) ;
			}


		view.setDrawColor( blendColor(MColor(1.0f, 1.0f, 0.0f), colO, fDrawHighlight) );	// Set color as desired

				// Draw MAX Sphere
				//
		dRad = dMaxTranslate ;
		for (i=0; i < nSegs; ++i)
			{
			double dPct = 2.0 * 3.14159 * ( i / (nSegs-1.0) ) ;
			double dPct2 = 2.0 * 3.14159 * ( (i+1.0) / (nSegs-1.0) ) ;
			double a = dRad * cos(dPct) ;
			double b = dRad * sin(dPct) ;
			double a2 = dRad * cos(dPct2) ;
			double b2 = dRad * sin(dPct2) ;
			glVertex3d( a, b, 0 ) ;
			glVertex3d( a2, b2, 0 ) ;

			glVertex3d( 0, a, b ) ;
			glVertex3d( 0, a2, b2 ) ;

			glVertex3d( a, 0, b ) ;
			glVertex3d( a2, 0, b2 ) ;
			}
		}	// end of draw translate



	glEnd() ; // End of LINES



			// Draw Weight Text
	if (nDrawText == 1 || (nDrawText == 2 && bSel))
		{
		MColor col0(0.0f, 1.0f, 1.0f) ;
		MColor col1(1.0f, 1.0f, 0.0f) ;
		MColor colText = ((1.0f-(float)dOutWeight) * col0) + ((float)dOutWeight * col1) ;
		view.setDrawColor( colText ) ;
		
		double dDrawLen = (1.0 + (dHead*1.5)) * dNeg ;
		MPoint ptDraw  ;
		if (nReadAxis == 0)
			ptDraw = MPoint(dDrawLen, 0,0) ;
		else if (nReadAxis == 1)
			ptDraw = MPoint(0, dDrawLen, 0) ;
		else if (nReadAxis == 2)
			ptDraw = MPoint(0,0, dDrawLen) ;

		char str[256];
		sprintf( str, "%s: %1.3f", nameParent.asChar(), dOutWeight );
		view.drawText( str, ptDraw, M3dView::kLeft ) ;
		}


	glPopAttrib();

	view.endGL();		// End openGL

}

// ---------------------------------------------------------------------------

/*
 * poseReader::blendColor() - Blend between col1 and colr2 as fBlend goes from 0 to 1
 */
MColor poseReader::blendColor(const MColor &col1, const MColor &col2, float fBlend)
{
	MColor col = ((1.0f-fBlend) * col1) + (fBlend * col2) ;
	return col ;
}

// ---------------------------------------------------------------------------
