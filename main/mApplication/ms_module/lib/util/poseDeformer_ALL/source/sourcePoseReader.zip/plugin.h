// --------------------------------------------------------------------------
// plugin.h - C++ Header File
// --------------------------------------------------------------------------
// Copyright �2004 Michael B. Comet  All Rights Reserved
// --------------------------------------------------------------------------
//
// DESCRIPTION:
//	Main heade  file for poseReader nodes.
//
// AUTHORS:
//		Michael B. Comet - comet@comet-cartoons.com
//
// VERSIONS:
//		1.00 - 09/11/04 - comet - Initial Rev.
//		1.06 - 10/17/04 - comet - Moved over smooth/gaussian options here.
//					Brought up version to match with poseDeformer.
//					Now has animCuve mode.
//		1.08 - 11/16/04 - comet - Now does translate
//		1.09 - 11/17/04 - comet - Has multiTrigger support for better usage
//				of multiple nodes at once.  Also has allowRotate option.
//		1.10 - 01/21/05 - mcomet - Now has nodestate HasNoEffect stop.
//
// --------------------------------------------------------------------------
//
//  poseReader - Pose Space Angle Reader Maya Plugin by Michael B. Comet
//  Copyright �2004 Michael B. Comet
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//   For information on poseDeformer contact:
//			Michael B. Comet - comet@comet-cartoons.com
//			or visit http://www.comet-cartooons.com/toons/
//
// --------------------------------------------------------------------------

/*
 * Defines
 */
#define VERSION		"1.10"

// 0x0010A580 - 0x0010A5BF  COMET BLOCK Assigned by ALIAS! 64 entries!
//
#define ID_BLOCKSTART			0x0010A580

// Previous entries used by other plugins I wrote...
#define ID_POSEREADER			ID_BLOCKSTART+5		// 0x0010A585
#define ID_MULTITRIGGER			ID_BLOCKSTART+8		// 0x0010A588


// --------------------------------------------------------------------------
