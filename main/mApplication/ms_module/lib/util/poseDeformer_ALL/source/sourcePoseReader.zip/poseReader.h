// --------------------------------------------------------------------------
// poseReader.h - C++ Header File
// --------------------------------------------------------------------------
// Copyright �2004 Michael B. Comet  All Rights Reserved
// --------------------------------------------------------------------------
//
// DESCRIPTION:
//	Header for poseReader node.
//
// AUTHORS:
//		Michael B. Comet - comet@comet-cartoons.com
//
// VERSIONS:
//		1.00 - 09/11/04 - comet - Initial Rev.
//		1.06 - 10/17/04 - comet - Moved over smooth/gaussian options here.
//					Brought up version to match with poseDeformer.
//					Now has animCuve mode.
//		1.08 - 11/16/04 - comet - Now does translate
//		1.09 - 11/17/04 - comet - Has multiTrigger support for better usage
//				of multiple nodes at once.  Also has allowRotate option.
//		1.10 - 01/21/05 - mcomet - Now has nodestate HasNoEffect stop.
//
// --------------------------------------------------------------------------
//
//  poseReader - Pose Space Angle Reader Maya Plugin by Michael B. Comet
//  Copyright �2004 Michael B. Comet
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//   For information on poseDeformer contact:
//			Michael B. Comet - comet@comet-cartoons.com
//			or visit http://www.comet-cartooons.com/toons/
//
// --------------------------------------------------------------------------

#ifndef _poseReaderNode
#define _poseReaderNode

/*
 * Includes
 */
#include <maya/MGlobal.h>
#include <maya/MPxLocatorNode.h>
#include <maya/MFnNumericAttribute.h>
#include <maya/MTypeId.h> 

#define VRADTODEG 57.295828
#define VDEGTORAD 0.0174533

typedef enum { eInterpLinear, eInterpSmoothStep, eInterpGaussian, eInterpCurve } EINTERPMODE ;

// --------------------------------------------------------------------------

/*
 * poseReader - Class definition for main pose calc node
 */
class poseReader : public MPxLocatorNode
{
public:
						poseReader();
	virtual				~poseReader(); 

	virtual MStatus		compute( const MPlug& plug, MDataBlock& data );

    virtual void 	draw( M3dView & view, const MDagPath & path, 
						M3dView::DisplayStyle dispStyle,
						M3dView::DisplayStatus status );

    virtual bool	isBounded() const;

	static  void*		creator();
	static  MStatus		initialize();

	static	MTypeId		id;

public:
	// Input Attrs
	static MObject		aPoseData ;				// Array Compound of input data
	static MObject		aWorldMatrixLiveIn ;	// mat for real jnt
	static MObject		aWorldMatrixPoseIn ;	// mat for pose loc
	static MObject		aMsgAnimCurve ;			// Msg attr from an animCurve.
	static MObject		aAnimCurveOutput ;		// Output from animCurve.
	static MObject		aReadAxis ;				// Enum of what axis, x,y,z,all to read?
	static MObject		aInterpMode ;			// How to interpolate from 0-180...
	static MObject		aAllowRotate ;			// 0-1 allowing of rotate or not.
	static MObject		aMinAngle ;				// Anything in here is one default 0
	static MObject		aMaxAngle ;				// up to here... default 180
	static MObject		aAllowTwist ;			// 0-1 allowing of twist or not.
	static MObject		aMinTwist ;				// Min Twist allowed
	static MObject		aMaxTwist ;				// Max Twist allowed
	static MObject		aAllowTranslate ;		// If on, translate anywhere is allowed.
	static MObject		aMinTranslate ;			// Min Translate allowed
	static MObject		aMaxTranslate ;			// Max Translate allowed

	static MObject		aDrawData ;				// Compound of drawing options
	static MObject		aDrawDetail ;			// Detail level of drawing.
	static MObject		aDrawCone ;				// Text cone options
	static MObject		aDrawText ;				// Text draw options
	static MObject		aDrawReverse ;			// For joints where the axis is backwards, you may want this.
	static MObject		aDrawHighlight ;		// Change to maya sel colors when selected?

	// Output Attrs
	static MObject		aOutWeight ;			// Output weight

private:
	double calcWtFromAngle(const double& dAngle, const double& dMinAngle, const double& dMaxAngle) ;
	double smoothStep(const double &dVal) ;
	double smoothGaussian(const double &dVal) ;
	MColor blendColor(const MColor &col1, const MColor &col2, float fBlend) ;
};

#endif

// --------------------------------------------------------------------------
