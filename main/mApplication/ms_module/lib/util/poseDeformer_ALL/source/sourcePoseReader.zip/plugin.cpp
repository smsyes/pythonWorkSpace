// --------------------------------------------------------------------------
// plugin.cpp - C++ File
// --------------------------------------------------------------------------
// Copyright �2004 Michael B. Comet  All Rights Reserved
// --------------------------------------------------------------------------
//
// DESCRIPTION:
//	Main loading file for poseReader command.
//
// AUTHORS:
//		Michael B. Comet - comet@comet-cartoons.com
//
// VERSIONS:
//		1.00 - 09/11/04 - comet - Initial Rev.
//		1.06 - 10/17/04 - comet - Moved over smooth/gaussian options here.
//					Brought up version to match with poseDeformer.
//					Now has animCuve mode.
//		1.08 - 11/16/04 - comet - Now does translate
//		1.09 - 11/17/04 - comet - Has multiTrigger support for better usage
//				of multiple nodes at once.  Also has allowRotate option.
//		1.10 - 01/21/05 - mcomet - Now has nodestate HasNoEffect stop.
//
// --------------------------------------------------------------------------
//
//  poseReader - Pose Space Angle Reader Maya Plugin by Michael B. Comet
//  Copyright �2004 Michael B. Comet
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation; either version 2 of the License, or
//   (at your option) any later version.
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
//   For information on poseDeformer contact:
//			Michael B. Comet - comet@comet-cartoons.com
//			or visit http://www.comet-cartooons.com/toons/
//
// --------------------------------------------------------------------------

/*
 * Includes
 */
#include <maya/MFnPlugin.h>
#include "poseReader.h"
#include "multiTrigger.h"

#include "plugin.h"



// --------------------------------------------------------------------------

/*
 * initializePlugin() - Main load of plugin
 *
 *	Description:
 *		this method is called when the plug-in is loaded into Maya.  It 
 *		registers all of the services that this plug-in provides with 
 *		Maya.
 *
 *	Arguments:
 *		obj - a handle to the plug-in object (use MFnPlugin to access it)
 *
 */
MStatus initializePlugin( MObject obj )
{ 
	MStatus   stat;
	MFnPlugin plugin( obj, "", "6.0", "Any");

	stat = plugin.registerNode( "poseReader", poseReader::id, poseReader::creator, poseReader::initialize, MPxNode::kLocatorNode );
	if (!stat) 
		stat.perror("registerNode poseReader");

	stat = plugin.registerNode( "multiTrigger", multiTrigger::id, multiTrigger::creator, multiTrigger::initialize, MPxNode::kDependNode );
	if (!stat) 
		stat.perror("registerNode multiTrigger");


	MGlobal::displayInfo(MString("poseReader ")+MString(VERSION)+MString(" - Built On: ") + MString(__DATE__) + MString(" ") + MString(__TIME__) ) ;
	MGlobal::displayInfo("poseReader Copyright �2004,2005 Michael B. Comet") ;
	MGlobal::displayInfo("poseReader comes with ABSOLUTELY NO WARRANTY; for details read the") ;
	MGlobal::displayInfo("license.txt file.  This is free software, and you are welcome to") ;
	MGlobal::displayInfo("redistribute it under certain conditions; See license.txt for details.") ;


	return stat;
}

// --------------------------------------------------------------------------


/*
 * uninitializePlugin() - Disable/unload main plugin
 *	
 *	Description:
 *		this method is called when the plug-in is unloaded from Maya. It 
 *		deregisters all of the services that it was providing.
 *
 *	Arguments:
 *		obj - a handle to the plug-in object (use MFnPlugin to access it)
 *
 */
MStatus uninitializePlugin( MObject obj)
{
	MStatus   stat;
	MFnPlugin plugin( obj );

	stat = plugin.deregisterNode( poseReader::id );
	if (!stat) 
		stat.perror("deregisterNode poseReader");

	stat = plugin.deregisterNode( multiTrigger::id );
	if (!stat) 
		stat.perror("deregisterNode multiTrigger");

	return stat;
}

// --------------------------------------------------------------------------
