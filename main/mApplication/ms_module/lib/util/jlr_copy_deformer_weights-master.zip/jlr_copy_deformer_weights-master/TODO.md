- [ ] Si en el target  se ha seleccionado como nuevo deformador que se cree otro nuevo del mismo tipo que el del source y que copie el nombre del deformador.
- [ ] Hacer que funcione con selección de componentes tanto de source como de target.
- [ ] Que el source pueda ser el pesado de una influencia de un skincluster. El target siempre debe ser un único weight-map.
- [ ] Que funcione con blenshapes. Hay que tener en cuenta los weights maps de cada target shapes
- [ ] Que sea capaz de hacer mirror y flip de un weight map.
- [ ] Ver como hacer para seleccionar los vértices por Open Maya.

