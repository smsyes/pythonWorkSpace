
### jlr_copy_deformer_weights.py - Python Script
**Author: Juan Carlos Lara.**

**Description:**

Tool for copy the deformer weights from one deformer to other deformer.

**Install:**

1- Copy the script file "jlr_copy_deformer_weights.py" into your scripts directory.

2- In the script editor add the following lines:

    import jlr_copy_deformer_weights as cdw
    
    cdw.open_copy_deformer_weights()